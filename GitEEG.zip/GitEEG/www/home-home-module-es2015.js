(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/home/home.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>\n      Power Consumer App\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list class=\"ios list-ios hydrated\">\n    <ion-list-header class=\"ios hydrated\">\n      Power Consumer\n    </ion-list-header>\n\n    <ion-item *ngFor=\"let booking of Bookings\" class=\"user-list\">\n      <ion-label>\n        <h5>\n          <ion-icon name=\"person\"></ion-icon> {{booking.name}}\n        </h5>\n        <p>\n          <ion-icon name=\"device\"></ion-icon> {{booking.device}}\n        </p>\n        <p>\n          <ion-icon name=\"call\"></ion-icon> {{booking.mobile}}\n        </p>\n      </ion-label>\n\n      <div class=\"item-note\" item-end>\n        <button ion-button clear [routerLink]=\"['/edit-appointment/', booking.$key]\">\n          <ion-icon name=\"create\" style=\"zoom:2.0\"></ion-icon>\n        </button>\n        <button ion-button clear (click)=\"deleteBooking(booking.$key)\">\n          <ion-icon name=\"trash\" style=\"zoom:2.0\"></ion-icon>\n        </button>\n      </div>\n    </ion-item>\n  </ion-list>"

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                }
            ])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".user-list h5 ion-icon,\n.user-list p ion-icon {\n  margin-right: 4px;\n  position: relative;\n  top: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcVXNlcnNcXGFuYS5hbGxpYW5cXFByb2plY3RBcHBzXFxlZWdQcm9qZWN0L3NyY1xcYXBwXFxob21lXFxob21lLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTs7RUFFSSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuLnVzZXItbGlzdCBoNSBpb24taWNvbixcbi51c2VyLWxpc3QgcCBpb24taWNvbiB7XG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRvcDogMXB4O1xufSIsIi51c2VyLWxpc3QgaDUgaW9uLWljb24sXG4udXNlci1saXN0IHAgaW9uLWljb24ge1xuICBtYXJnaW4tcmlnaHQ6IDRweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDFweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _shared_appointment_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../shared/appointment.service */ "./src/app/shared/appointment.service.ts");



let HomePage = class HomePage {
    constructor(aptService) {
        this.aptService = aptService;
        this.Bookings = [];
    }
    ngOnInit() {
        this.fetchBookings();
        let bookingRes = this.aptService.getBookingList();
        bookingRes.snapshotChanges().subscribe(res => {
            this.Bookings = [];
            res.forEach(item => {
                let a = item.payload.toJSON();
                a['$key'] = item.key;
                this.Bookings.push(a);
            });
        });
    }
    fetchBookings() {
        this.aptService.getBookingList().valueChanges().subscribe(res => {
            console.log(res);
        });
    }
    deleteBooking(id) {
        console.log(id);
        if (window.confirm('Do you really want to delete?')) {
            this.aptService.deleteBooking(id);
        }
    }
};
HomePage.ctorParameters = () => [
    { type: _shared_appointment_service__WEBPACK_IMPORTED_MODULE_2__["AppointmentService"] }
];
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: __webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/index.js!./src/app/home/home.page.html"),
        styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_appointment_service__WEBPACK_IMPORTED_MODULE_2__["AppointmentService"]])
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map