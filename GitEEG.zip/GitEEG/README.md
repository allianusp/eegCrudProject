# ionic-firebase-crud

A complete step by step tutorial on creating Ionic 4, Firebase Realtime Database, Cordova and Angular 8 doctors appointment CRUD (Create, Read, Update, Delete) mobile app.

[Build Ionic 4 Firebase CRUD App with Angular 8](https://www.positronx.io/build-ionic-firebase-crud-app-with-angular/)


To connect with Firebase database insert your Firebase project keys inside the `environment.prod.ts` and `environment.ts`file.