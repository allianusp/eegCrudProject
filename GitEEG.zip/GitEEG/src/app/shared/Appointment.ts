export class Appointment {
    $key: string;
    name: string;
    email: string
    mobile: number;
    device: string;
}