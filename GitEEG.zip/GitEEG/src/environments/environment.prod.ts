export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCjtWMW_nDK0yBcdVaUjF9PQvDpQLOT2HQ",
    authDomain: "ioniceeg.firebaseapp.com",
    databaseURL: "https://ioniceeg.firebaseio.com",
    projectId: "ioniceeg",
    storageBucket: "ioniceeg.appspot.com",
    messagingSenderId: "909195940881",
    appId: "1:909195940881:web:a008e56a9dd25515f78db0",
    measurementId: "G-EEL6PYTGTR"
  }
};